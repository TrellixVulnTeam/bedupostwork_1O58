import { createApp } from 'vue'
import App from './components/Data.vue'

createApp(App).mount('#app')
