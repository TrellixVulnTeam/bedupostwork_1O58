class InvestmentRepositoryContract {
    getId() {
        throw new Error("You have to implement the method getId");
    }
}

module.exports = InvestmentRepositoryContract;