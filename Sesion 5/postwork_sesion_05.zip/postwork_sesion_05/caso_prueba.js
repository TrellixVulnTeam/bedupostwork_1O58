//Importar TestCafe
import {Selector} from 'testcafe';

fixture`Getting Started`
    .page`https://google.com`;
/*

document.querySelector("body > div.L3eUgb > div.o3j99.ikrT4e.om7nvf > form > div:nth-child(1) > div.A8SBwf > div.RNNXgb > div > div.a4bIc > input")
html/body/div[1]/div[3]/form/div[1]/div[1]/div[1]/div/div[2]/input
#rso > div:nth-child(1) > div > div.NJo7tc.Z26q7c.jGGQ5e > div > a > h3
#rso > div:nth-child(1) > div > div.NJo7tc.Z26q7c.jGGQ5e > div > a
//*[@id="rso"]di/v[1]
#rso > div:nth-child(1) > div > div > div > div > link
#rso > div:nth-child(1) > link
document.querySelector("#rso > div:nth-child(1) > div > div > div > div > div > div > div.yuRUbf > a")
*/
test('My first Google test', async t => {
    await t
        //.typeText('#developer-name', 'John Smith')
        //.click('#submit-button')
        //*[@id="app"]/div/button
        .typeText('[class="gLFyf gsfi"]','cebsc.com')
        
        .click('[class="gNO89b"]')
        //.expect(Selector('#article-header')).
        //.click('#rso > div:nth-child(1) div > div.NJo7tc.Z26q7c.jGGQ5e > div > a')         
       
});