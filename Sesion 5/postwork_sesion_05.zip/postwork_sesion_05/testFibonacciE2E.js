//Importar TestCafe
import {Selector} from 'testcafe';

fixture`Getting Started`
    .page`http://localhost:8080`;

test('Test input 7', async t => {
    await t
        //.typeText('#developer-name', 'John Smith')
        //.click('#submit-button')
        //*[@id="app"]/div/button
        .click('[data-test-id="number-to-calculate-fibonacci"]')
        .pressKey('ctrl+a delete')
        .typeText('[data-test-id="number-to-calculate-fibonacci"]','7')
        .click('[data-test-id="calculate-button"]')
        // Usa las verificaciones pra checar si el valor actual corresponde con el vlaor esperado
        .expect(Selector('[data-test-id="result"]').innerText).eql('13');
        
});

test('input number 4', async t => {
    await t
        //.typeText('#developer-name', 'John Smith')
        //.click('#submit-button')
        //*[@id="app"]/div/button
        .click('[data-test-id="number-to-calculate-fibonacci"]')
        .pressKey('ctrl+a delete')
        .typeText('[data-test-id="number-to-calculate-fibonacci"]','4')
        .click('[data-test-id="calculate-button"]')
        // Usa las verificaciones pra checar si el valor actual corresponde con el vlaor esperado
        .expect(Selector('[data-test-id="result"]').innerText).eql('3');
       
});

test('input big numbers 40', async t => {
    await t
        //.typeText('#developer-name', 'John Smith')
        //.click('#submit-button')
        //*[@id="app"]/div/button
        .click('[data-test-id="number-to-calculate-fibonacci"]')
        .pressKey('ctrl+a delete')
        .typeText('[data-test-id="number-to-calculate-fibonacci"]','40')
        .click('[data-test-id="calculate-button"]')
        // Usa las verificaciones pra checar si el valor actual corresponde con el vlaor esperado
        .expect(Selector('[data-test-id="result"]').innerText).eql('102334155');
       
});

/*
test.only('input  numbers 0', async t => {
    await t
        //.typeText('#developer-name', 'John Smith')
        //.click('#submit-button')
        //*[@id="app"]/div/button
        .click('[data-test-id="number-to-calculate-fibonacci"]')
        .pressKey('ctrl+a delete')
        .typeText('[data-test-id="number-to-calculate-fibonacci"]','0')
        .click('[data-test-id="calculate-button"]')
        // Usa las verificaciones pra checar si el valor actual corresponde con el vlaor esperado
        .expect(Selector('[data-test-id="result"]').innerText).eql('0');
       
});
*/