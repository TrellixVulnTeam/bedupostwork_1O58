const InvestmentRepository = require("./InvestmentRepository");

class Investment {
    id;
    name;
    description;
    interest;
    startingAmount;
    finalAmount;
    startDate;
    endDate;
    taxToPay;
    finalAmountAfterTaxes;
    period;

    constructor(id, name, description, interest, startingAmount, finalAmount, startDate, endDate) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.interest = interest;
        this.startingAmount = startingAmount;
        this.finalAmount = finalAmount;
        this.startDate = startDate;
        this.endDate = endDate;
        this.taxToPay = 0;
        this.finalAmountAfterTaxes = 0;
        this.period = 28;
        
    }

    static addInvestment(name, description, interest, startingAmount, startDate, duration, repository) {
        const endDate = startDate;
        endDate.setDate(endDate.getDate() + duration);

        const finalAmount = Investment._calculateFinalAmount(interest, startingAmount, duration);

        return new Investment(repository.getId(), name, description, interest, startingAmount, finalAmount, startDate, endDate)
    }

    static _calculateFinalAmount(interest, startingAmount, duration) {
        const bankingYear = 360;
        const interestAsPercentage = interest / 100;
        return startingAmount * (1 + (((interestAsPercentage) / bankingYear) * duration));
    }
    
    static getInvestmentDetails(id)
    {
        const repository = new InvestmentRepository();
        //console.log(`id  = ${id}`);
        const investment =  repository.getDetails(id);
       
        const totalAmount = Investment._calculateFinalAmount(investment.interest,investment.startingAmount, investment.period);
        const taxToPay = Investment._calculateTaxToPay(totalAmount,investment.startingAmount); 
        const finalAmountAfterTaxes = Investment.getFinalAmountAfterTaxes(
            totalAmount,
            taxToPay
        );
        investment.finalAmountAfterTaxes = finalAmountAfterTaxes;
        investment.taxToPay = taxToPay;
        //console.log(investment);
        return investment;
    }

    static _calculateTaxToPay(totalAmount,startingAmount)
    {   
        //const totalAmount = Investment._calculateFinalAmount(interest,startingAmount,duration);
        const expectedTaxToPay =  ((totalAmount - startingAmount) * (32.00/100.00));
        return expectedTaxToPay;

    }
    
    static getFinalAmountAfterTaxes(totalAmount,taxToPay)
    {
        
        return totalAmount - taxToPay;
        
    }
}


module.exports = Investment;