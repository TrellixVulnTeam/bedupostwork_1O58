const InvestmentRepositoryContract = require("./InvestmentRepositoryContract");
const { v4: uuidv4 } = require('uuid');
const annualInterest = 4.5;

const mockInvestments = 
[   {
        id              : '951007b4-30c7-47ec-bbc7-2c0a04183a16',
        name            : "Investor 1",
        description     : "Investor 1",
        interest        : annualInterest,
        startingAmount  : 10,
        finalAmount     : 0,
        startDate       : '2022-01-01',
        endDate         : '2022-12-01',
        taxToPay        : 0,
        finalAmountAfterTaxes : 0,
        period          : 28
    },
    {
        id              :'f18fd0cd-6042-49b7-8c06-3641975c2f5f',
        name            : "Investor 2",
        description     : "descripcion Investor 2",
        interest        : annualInterest,
        startingAmount  : 20,
        finalAmount     : 0,
        startDate       : '2022-01-01',
        endDate         : '2022-12-01',
        taxToPay        : 0,
        finalAmountAfterTaxes : 0,
        period          : 28
    },
    {
        id              :'3fb98c66-8d09-4fe6-91f3-2a59730db01a',
        name            : "Investor 3",
        description     : "Investor 3",
        interest        : annualInterest,
        startingAmount  : 15,
        finalAmount     : 0,
        startDate       : '2022-01-01',
        endDate         : '2022-12-01',
        taxToPay        : 0,
        finalAmountAfterTaxes : 0,
        period          : 28
    },
    {
        id              :'b0da3b0f-2c1f-4de4-b425-6277b242d569',
        name            : "Investor 4",
        description     : "Investor 4",
        interest        : annualInterest,
        startingAmount  : 5,
        finalAmount     : 0,
        startDate       : '2022-01-01',
        endDate         : '2022-12-01',
        taxToPay        : 0,
        finalAmountAfterTaxes : 0,
        period          : 28
    }
]

class InvestmentRepository extends InvestmentRepositoryContract {
    constructor(dbConnection) {
        super();
    }
    getId() {
        
        return uuidv4();
    }

    getDetails(id)
    {
        for(let i = 0; i < mockInvestments.length ; i++)
        {
            if(mockInvestments[i].id == id)
            {
                //console.log( mockInvestments[i]);
                return mockInvestments[i];
            }
        }
    }
}

module.exports = InvestmentRepository;