
class InvestmentRepositoryContract {
    getId() {
        throw new Error("You have to implement the method getId");
    }
    getDetails(id)
    {
        throw new Error("Id does not exist");
    }
}

module.exports = InvestmentRepositoryContract;