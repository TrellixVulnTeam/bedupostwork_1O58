const request = require("supertest");
const app = require("./app");
const InvestmentRepository = require("./InvestmentRepository");


describe('add-investment endpoint', () => {
    
    it('returns new created investment', async () => {
        const name = "cetes 28 days";
        const description = "cetes for 28 days";
        const interest = 4.5;
        const startingAmount = 10;
        const durationDays = 28;
        const startDate = '2021-01-01';

        const response = await request(app).post("/add-investment").send({
            name, description, interest, startingAmount, duration: durationDays, startDate
        });

        //expect(response.statusCode).toBe(500);
        //expect(response.body.name).toBe(undefined);
        expect(response.statusCode).toBe(200);
        expect(response.body.name).toBe(name);
        expect(response.body.description).toBe(description);
        expect(response.body.interest).toBe(interest);
        expect(response.body.startingAmount).toBe(startingAmount);
        //expect(response.body.endDate).toBe(expectedEndDate)
    });

    it('calculates final amount based on starting amount plus interest generated in the amount of time', async() => {
        const name = "cetes 28 days";
        const description = "cetes for 28 days";
        const interest = 4.5;
        const startingAmount = 10;
        const durationDays = 28;
        const startDate = new Date('2021-01-01');
        //const repository = new InvestmentRepositoryStub('123e4567-e89b-12d3-a456-426655440000');
        const expectedFinalAmount = 10 * (1 + (((interest / 100) / 360) * durationDays));

        const response = await request(app).post("/add-investment").send({
            name, description, interest, startingAmount, duration: durationDays, startDate
        });

        expect(response.body.finalAmount).toEqual(expectedFinalAmount);
    })

    it('get investment detail when valid id provided', async () => {
        const name = "xcetes 28 days";
        const description = "cetes for 28 days";
        const interest = 4.5;
        const startingAmount = 10;
        const durationDays = 28;
        const startDate = new Date('2021-01-01');
        
        const response = await request(app).post("/add-investment").send({
            name, description, interest, startingAmount, duration: durationDays, startDate
        });

        expect(response.body.name).toEqual(name);
    })
})
