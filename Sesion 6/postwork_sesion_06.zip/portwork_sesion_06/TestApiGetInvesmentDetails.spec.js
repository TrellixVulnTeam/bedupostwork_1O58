const request = require("supertest");
const app = require("./app");

/*
function totalTaxToPay (startingAmount,interest,period,taxToPay){
    const bankDays=360;
    const totalEarned = startingAmount * (1 + (((interest / 100) / bankDays) * period));
    const expectedTaxToPay =  ((totalEarned - startingAmount) * (taxToPay/100));
    //console.log (`total earned: ${totalEarned} ,  tax to pay : ${expectedTaxToPay}`);
    return expectedTaxToPay;
  
}
*/
/*
describe('Get investment details endpoint', () => {
    
    it('returns new created investment', async () => {
        const name = "cetes 28 days";
        const description = "cetes for 28 days";
        const interest = 4.5;
        const startingAmount = 10;
        const durationDays = 28;
        const startDate = '2021-01-01';

        const response = await request(app).post("/add-investment").send({
            name, description, interest, startingAmount, duration: durationDays, startDate
        });

        //expect(response.statusCode).toBe(500);
        //expect(response.body.name).toBe(undefined);
        expect(response.statusCode).toBe(200);
        expect(response.body.name).toBe(name);
        expect(response.body.description).toBe(description);
        expect(response.body.interest).toBe(interest);
        expect(response.body.startingAmount).toBe(startingAmount);
        //expect(response.body.endDate).toBe(expectedEndDate)
    });
});
*/
describe('Sesion 06 Postwork', () => {

    it('get taxes to pay', async () => {
          
        const id = "f18fd0cd-6042-49b7-8c06-3641975c2f5f";
        const startingAmount = 20;
        const durationDays = 28;
        const interest = 4.5;
        const isr=32;

        const expectedTotalTaxToPay =0.02240000000000009;// totalTaxToPay(startingAmount,interest,durationDays,isr);

        const response = await request(app).get("/get-details").send({
            id
        });

        console.log(`expected: ${expectedTotalTaxToPay} => recived : ${response.body.taxToPay}`);
    
        
        expect(response.body.taxToPay).toEqual(expectedTotalTaxToPay);
    })


    it('get final amount after taxes',async () => {
           
        const id = "f18fd0cd-6042-49b7-8c06-3641975c2f5f";
        const startingAmount = 20;
        const durationDays = 28;
        const interest = 4.5;
        const isr=32;
        
        const expectedFinalAmountAfterTaxes = 20.07 - 0.02240000000000009; 
            //finalAmountAfterTaxes(startingAmount,interest,durationDays);
        
        const response = await request(app).get("/get-details").send({
            id
        });
        console.log(`expectedu: ${expectedFinalAmountAfterTaxes} , received: ${response.body.finalAmountAfterTaxes}`);
        
         expect(response.body.finalAmountAfterTaxes).toEqual(expectedFinalAmountAfterTaxes);
    })
    
})