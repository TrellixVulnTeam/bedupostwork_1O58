
const Investment = require("./Investment");
const InvestmentRepository = require("./InvestmentRepository");
/*
class InvestmentRepositoryStub extends InvestmentRepositoryContract {
    constructor(id) {
        super();
        this.id = id;
    }

    getId() {
        return this.id;
    }
}
*/

function totalTaxToPay (startingAmount,interest,period,taxToPay){
    const bankDays=360;
    const totalEarned = startingAmount * (1 + (((interest / 100) / bankDays) * period));
    const expectedTaxToPay =  ((totalEarned - startingAmount) * (taxToPay/100));
    return expectedTaxToPay;
  
}

function finalAmountAfterTaxes(startingAmount,interest,period,totalTaxToPay)
{
    const bankDays=360;
    //const totalTaxToPay = totalTaxToPay(startingAmount,interest,period,32);
    const totalEarned = startingAmount * (1 + (((interest / 100) / bankDays) * period));
   
    return totalEarned - totalTaxToPay;
}

    describe('Add new investment', () => {
        /*
        it('calculates end date based on initial day plus duration', () => {
            const name = "cetes 28 days";
            const description = "cetes for 28 days";
            const interest = 4.5;
            const startingAmount = 10;
            const durationDays = 28;
            const startDate = new Date('2021-01-01');
            const repository = new InvestmentRepositoryStub('123e4567-e89b-12d3-a456-426655440000');
            const expectedEndDate = new Date('2021-01-29');
            const investment = Investment.addInvestment(name, description, interest, startingAmount, startDate, durationDays, repository);
            expect(investment.endDate).toEqual(expectedEndDate);
        });

        it('calculates final amount based on starting amount plus interest generated in the amount of time', () => {
            const name = "cetes 28 days";
            const description = "cetes for 28 days";
            const interest = 4.5;
            const startingAmount = 10;
            const durationDays = 28;
            const startDate = new Date('2021-01-01');
            const repository = new InvestmentRepositoryStub('123e4567-e89b-12d3-a456-426655440000');
            const expectedFinalAmount = 10 * (1 + (((interest / 100) / 360) * durationDays));

            const investment = Investment.addInvestment(name, description, interest, startingAmount, startDate, durationDays, repository);
            
            
            console.log(investmentArray);

            expect(investment.finalAmount).toEqual(expectedFinalAmount);
        })

        it('assigns id gotten from repository', () => {
            const name = "cetes 28 days";
            const description = "cetes for 28 days";
            const interest = 4.5;
            const startingAmount = 10;
            const durationDays = 28;
            const startDate = new Date('2021-01-01');
            const expectedId = '123e4567-e89b-12d3-a456-426655440000';
            const repository = new InvestmentRepositoryStub(expectedId);
            const expectedFinalAmount = 10 * (1 + (((interest / 100) / 360) * durationDays));

            const investment = Investment.addInvestment(name, description, interest, startingAmount, startDate, durationDays, repository);

            expect(investment.id).toEqual(expectedId);
        })
    })
*/
describe('Sesion 06 Postwork', () => {
        it('get taxes to pay', () => {
           
            const validId = "f18fd0cd-6042-49b7-8c06-3641975c2f5f";
            const startingAmount = 20;
            const durationDays = 28;
            const interest = 4.5;
            const isr=32;
            
            const expectedTotalTaxToPay = totalTaxToPay(startingAmount,interest,durationDays,isr);
            //const repository = new InvestmentRepository();
            
            const recivedInvestment = Investment.getInvestmentDetails(validId); //, repository,durationDays);
           
            console.log(`expected: ${expectedTotalTaxToPay} => recived : ${recivedInvestment.taxToPay}`);
            
             expect(expectedTotalTaxToPay).toEqual(recivedInvestment.taxToPay);
        })
        it('get final amount after taxes', () => {
           
            const validId = "f18fd0cd-6042-49b7-8c06-3641975c2f5f";
            const name            = "Investor 2";
            const description     = "descripcion Investor 2";
            const interest        = 4.5;
            const startingAmount  = 20;
            const finalAmount     = 0;
            const startDate       = '2022-01-01';
            const endDate         = '2022-12-01';
            let expectedTaxToPay        = 0;
            let expectedFinalAmountAfterTaxes = 0;
            const period          = 28;
           
            const durationDays = 28;
            const isr=32;

            //0.02240000000000009
            
            expectedTaxToPay = totalTaxToPay(startingAmount,interest,durationDays,isr);
            expectedFinalAmountAfterTaxes = finalAmountAfterTaxes(startingAmount,interest,durationDays,expectedTaxToPay);
            
            console.log(`total tax to pay: ${expectedTaxToPay} , final after taxes: ${expectedFinalAmountAfterTaxes}`);
            

            const recivedInvestment = Investment.getInvestmentDetails(validId);
            //console.log(recivedInvestment);
            console.log(`expected: ${expectedFinalAmountAfterTaxes} , received: ${recivedInvestment.finalAmountAfterTaxes}`);
            
             expect(recivedInvestment.finalAmountAfterTaxes).toEqual(expectedFinalAmountAfterTaxes);
        })
    })
})



