
const { v4: uuidv4 } = require('uuid');
ids = {}
for ( i = 0 ; i<4 ; i++)
{
    ids[i] = uuidv4();

}

console.log(ids);